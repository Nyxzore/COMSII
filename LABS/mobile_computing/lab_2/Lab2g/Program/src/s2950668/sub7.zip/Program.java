//package s2950668;
import java.util.Scanner; 
public class Program {
	public static void main(String args []) {
		Scanner in = new Scanner(System.in);
		String[] arr = new String[10]; 
		
		for(int i=0; i<10; i++) {
			arr[i]= in.nextLine();
		}
		
		in.close();
		
		for(int i=9; i>=0; i--) {
			System.out.println(arr[i]);
		}
		
	}
}
