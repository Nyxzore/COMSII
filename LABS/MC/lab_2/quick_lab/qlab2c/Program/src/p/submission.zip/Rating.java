//package p;
public class Rating {
	String username; 
	int score; 
	
	public Rating(String u, int s) {
		username = u;
		score = s;
	}
	
	void setScore(int r){
		score = r;
		
	}
	int getScore(){
		return score;
	}
	void setUsername(String u){
		username = u;
	}
	String getUsername(){
		return username; 
	}
	
	public static void main(String args []){
		Rating myRating = new Rating("movieguy87", 7);
	}
}
